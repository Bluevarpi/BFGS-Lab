No font binaries are bundled. CMU Unicode fonts are resolved from the system installation or the TeX Live font tree.
