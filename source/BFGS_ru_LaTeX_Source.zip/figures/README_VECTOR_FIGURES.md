# TikZ scientific figures

RS-F03, RS-F04, RS-F06 and RS-F07 are implemented directly with TikZ primitives. No PNG, JPEG, PDF, SVG, EPS or WebP figure file is required. The plotted numerical coordinates are the values used in the numerical-experiment section of this report.

Historical corrected RS-F07 PNG provenance SHA-256: `2475182a23b0a6f8fc44b493064177887b7ca524ed59d529a65076d7dd049f0c`.
