#!/usr/bin/env python3
"""Optimize BFGS-Lab GUI screenshots for thesis use.

The screenshots contain factual UI text, source code and numeric values, so this
script intentionally avoids generative re-drawing. It removes only uniform black
right padding, then uses an adaptive indexed PNG palette to reduce file size while
preserving crisp UI/text edges.
"""
from pathlib import Path
from PIL import Image
import argparse


def crop_uniform_black_right(im: Image.Image) -> Image.Image:
    rgb = im.convert("RGB")
    px = rgb.load()
    w, h = rgb.size
    right = w
    while right > 0:
        # A column is removable only when it is exactly black from top to bottom.
        if all(px[right - 1, y] == (0, 0, 0) for y in range(h)):
            right -= 1
        else:
            break
    return rgb.crop((0, 0, right, h)) if right < w else rgb


def optimize(path: Path, colors: int = 64) -> tuple[tuple[int,int], tuple[int,int], int, int]:
    before = path.stat().st_size
    with Image.open(path) as im:
        old_size = im.size
        cropped = crop_uniform_black_right(im)
        # UI screenshots have a small, flat color vocabulary; adaptive palette
        # quantization preserves text/line edges much better than JPEG.
        q = cropped.quantize(colors=colors, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
        q.save(path, format="PNG", optimize=True, compress_level=9)
        new_size = q.size
    after = path.stat().st_size
    return old_size, new_size, before, after


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("directory", type=Path)
    ap.add_argument("--colors", type=int, default=64)
    args=ap.parse_args()
    for p in sorted(args.directory.glob("*.png")):
        old_s,new_s,b,a=optimize(p,args.colors)
        print(f"{p.name}: {old_s} {b} B -> {new_s} {a} B ({100*(1-a/b):.1f}% smaller)")

if __name__ == "__main__":
    main()
