#!/usr/bin/env python3
from __future__ import annotations
import argparse, ast, csv, math, statistics
from pathlib import Path
from collections import Counter, defaultdict

ap=argparse.ArgumentParser()
ap.add_argument('--lang',choices=['zh','ru'],required=True)
ap.add_argument('--root',default=None)
args=ap.parse_args()
ROOT=Path(args.root).resolve() if args.root else Path(__file__).resolve().parents[1]
DATA=ROOT/'data'/'appendix_b_data'
OUT=ROOT/'generated_appendix_b'
OUT.mkdir(exist_ok=True)
LANG=args.lang

def readcsv(name):
    with (DATA/name).open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))
O=readcsv('original_246_reference_summary.csv')
S=readcsv('supplementary_105_master.csv')
SF=readcsv('supplementary_family_summary.csv')
RQ=readcsv('supplementary_rq_findings.csv')
F4=readcsv('f4_strong_wolfe_analysis_bridge.csv')
OD={r['planned_run_id']:r for r in O}; SD={r['supp_run_id']:r for r in S}

T={
'zh':{
 'continued':'（续）','run':'Run','family':'实验族','benchmark':'Benchmark','n':'n','status':'终止状态','k':'迭代','ng':'Ng','nf':'Nf','step':'步长/线搜索','h0':'H0','update':'更新','weight':'权重','feature':'代表因素','count':'数量','success':'成功','non':'非成功','scope':'范围','evidence':'核心证据','file':'电子文件','rows':'行数','role':'内容','rq':'RQ','dir':'方向','radius':'半径','anchor':'Anchor','newstatus':'补充状态','identity':'Identity anchor','k1e2':'SPD 1e2','k1e4':'SPD 1e4','kappa':'条件数','time':'时间(s)','rss':'RSS(MB)','factor':'因素','changed':'状态变化','schanged':'成功性变化','from':r'STRONG\_WOLFE','to':'WOLFE','gfrom':'Ng(SW)','gto':'Ng(W)','secfrom':'割线残差(SW)','secto':'割线残差(W)','metric':'指标','value':'结果','fieldgroup':'字段组','fields':'核心字段'},
'ru':{
 'continued':'(продолжение)','run':'Run','family':'Серия','benchmark':'Benchmark','n':'n','status':'Terminal status','k':'Итерации','ng':'Ng','nf':'Nf','step':'Шаг / line search','h0':'H0','update':'Update','weight':'Weight','feature':'Ключевой фактор','count':'Число','success':'Успех','non':'Неуспех','scope':'Диапазон','evidence':'Ключевые данные','file':'Электронный файл','rows':'Строки','role':'Содержание','rq':'RQ','dir':'Направление','radius':'Радиус','anchor':'Anchor','newstatus':'Доп. status','identity':'Identity anchor','k1e2':'SPD 1e2','k1e4':'SPD 1e4','kappa':'Число обусловл.','time':'Время(s)','rss':'RSS(MB)','factor':'Фактор','changed':'Изменение status','schanged':'Изменение success','from':r'STRONG\_WOLFE','to':'WOLFE','gfrom':'Ng(SW)','gto':'Ng(W)','secfrom':'Secant(SW)','secto':'Secant(W)','metric':'Показатель','value':'Результат','fieldgroup':'Группа полей','fields':'Ключевые поля'}
}[LANG]

REPL={
 '&':r'\&','%':r'\%','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}','\\':r'\textbackslash{}',
 '≤':r'$\leq$'
}
def esc(s):
    if s is None: return r'\textemdash'
    s=str(s)
    if s=='' or s.upper() in {'NA','N/A','NAN','NONE'}: return r'\textemdash'
    return ''.join(REPL.get(ch,ch) for ch in s)
def code(s):
    if s is None or str(s)=='' or str(s).upper() in {'NA','N/A','NAN','NONE'}: return r'\textemdash'
    return r'\BFGSCode{'+esc(str(s))+r'}'
def intval(x):
    try: return str(int(float(x)))
    except: return r'\textemdash'
def num(x,digits=4):
    if x is None or str(x)=='' or str(x).upper() in {'NA','N/A','NAN','NONE'}: return r'\textemdash'
    try:
        v=float(x)
    except: return esc(x)
    if v==0: return '0'
    av=abs(v)
    if av>=1e4 or av<1e-3: return rf'\(\displaystyle {v:.{digits}e}\)'
    return rf'\(\displaystyle {v:.{digits}g}\)'
def yes(x):
    return '✓' if str(x).lower() in {'true','1','yes'} else '—'

def longtable(filename,caption,label,columns,headers,rows,fontsize='7.6pt',leading='9.0pt',tabcolsep='1.6pt'):
    with (OUT/filename).open('w',encoding='utf-8') as f:
        f.write('\\begingroup\n')
        f.write(rf'\fontsize{{{fontsize}}}{{{leading}}}\selectfont'+'\n')
        f.write(rf'\setlength{{\tabcolsep}}{{{tabcolsep}}}'+'\n')
        f.write(r'\renewcommand{\arraystretch}{1.13}'+'\n')
        f.write(rf'\begin{{longtable}}{{@{{}}{columns}@{{}}}}'+'\n')
        f.write(rf'\caption{{{caption}}}\label{{{label}}}\\'+'\n')
        f.write(r'\toprule '+' & '.join(headers)+r' \\'+'\n\\midrule\n\\endfirsthead\n')
        f.write(rf'\multicolumn{{{len(headers)}}}{{c}}{{\small\itshape {T["continued"]}}}\\'+'\n')
        f.write(r'\toprule '+' & '.join(headers)+r' \\'+'\n\\midrule\n\\endhead\n')
        f.write(rf'\midrule\multicolumn{{{len(headers)}}}{{r}}{{\scriptsize {T["continued"]}}}\\\endfoot'+'\n')
        f.write(r'\bottomrule\endlastfoot'+'\n')
        for row in rows: f.write(' & '.join(row)+r' \\'+'\n')
        f.write('\\end{longtable}\n\\endgroup\n')

# Clean previous generated files: this compact generator owns the directory.
for p in OUT.glob('*.tex'):
    p.unlink()

# Dataset/schema overview
rows=[
 [esc('Original design'), '256', esc('10 VALIDATION_ONLY + 246 scientific') if LANG=='zh' else esc('10 VALIDATION_ONLY + 246 scientific')],
 [esc('Original scientific'), '246', esc('61 success + 185 scientific non-success')],
 [esc('Supplementary'), '105', esc('24 success + 81 scientific non-success')],
 [esc('Local reproduction'), '246/246', esc('terminal / iteration-evaluation / numeric scientific fields matched')],
]
longtable('dataset_overview.tex','数据层级与实验规模。' if LANG=='zh' else 'Уровни данных и объём экспериментов.','tab:appB-dataset-overview','L{48mm}L{30mm}L{92mm}',[T['scope'],T['count'],T['evidence']],rows,fontsize='8.0pt',leading='9.4pt')

# Field groups, not every row.
if LANG=='zh':
    rows=[
      ['身份/问题',code('planned_run_id / supp_run_id')+', '+code('family / RQ')+', '+code('benchmark_instance_id')+', '+code('dimension')],
      ['初始条件',code('start_point_id')+', '+code('start_direction_id / radius')+', '+code('initial_matrix_id / kappa_H')],
      ['算法配置',code('update_implementation_id')+', '+code('weight_id')+', '+code('step_line_search_id')],
      ['停止/预算',code('tolerance_profile_id')+', '+code('budget_profile_id')],
      ['终态/工作量',code('terminal_status')+', '+code('iterations')+', '+code('Nf / Ng / line-search trials')],
      ['数值诊断',code('final_f / ||g||')+', '+code('secant residual / symmetry / lambda_min / known errors')],
      ['原始轨迹',code('iteration-history.csv')+', '+code('line-search-trials.csv')+', '+code('vector-history.csv')],
    ]
else:
    rows=[
      ['Идентичность / задача',code('planned_run_id / supp_run_id')+', '+code('family / RQ')+', '+code('benchmark_instance_id')+', '+code('dimension')],
      ['Начальные данные',code('start_point_id')+', '+code('start_direction_id / radius')+', '+code('initial_matrix_id / kappa_H')],
      ['Алгоритм',code('update_implementation_id')+', '+code('weight_id')+', '+code('step_line_search_id')],
      ['Остановка / budget',code('tolerance_profile_id')+', '+code('budget_profile_id')],
      ['Итог / трудоёмкость',code('terminal_status')+', '+code('iterations')+', '+code('Nf / Ng / line-search trials')],
      ['Диагностика',code('final_f / ||g||')+', '+code('secant residual / symmetry / lambda_min / known errors')],
      ['Полные траектории',code('iteration-history.csv')+', '+code('line-search-trials.csv')+', '+code('vector-history.csv')],
    ]
longtable('field_groups.tex','核心字段与完整电子数据的对应关系。' if LANG=='zh' else 'Ключевые поля и соответствующие полные электронные данные.','tab:appB-field-groups','L{43mm}L{127mm}',[T['fieldgroup'],T['fields']],rows,fontsize='7.8pt',leading='9.2pt')

# Benchmark/factor coverage by family.
bench={b:{'odims':set(),'sdims':set(),'ok':set(),'sk':set()} for b in [f'B-{i:02d}' for i in range(1,7)]}
for r in O:
    b=r['benchmark_id']; bench[b]['odims'].add(int(r['dimension']))
    bi=r['benchmark_instance_id']
    if b=='B-02':
        if '-K1E2' in bi: bench[b]['ok'].add('1e2')
        elif '-K1E6' in bi: bench[b]['ok'].add('1e6')
        elif bi.endswith('-K1'): bench[b]['ok'].add('1')
for r in S:
    b=r['benchmark_id']; bench[b]['sdims'].add(int(r['dimension']))
    if b=='B-02' and r.get('condition_number') not in ('','NA'):
        try:
            k=float(r['condition_number']); bench[b]['sk'].add(f'1e{int(round(math.log10(k)))}')
        except: pass
rows=[]
for b,v in bench.items():
    od=','.join(map(str,sorted(v['odims']))) or '—'; sd=','.join(map(str,sorted(v['sdims']))) or '—'
    ok=','.join(sorted(v['ok'],key=lambda x:float(x.replace('e','e')))) if v['ok'] else '—'
    sk=','.join(sorted(v['sk'],key=lambda x:float(x.replace('e','e')))) if v['sk'] else '—'
    rows.append([code(b),esc(od),esc(sd),esc(ok),esc(sk)])
cap='Benchmark family 的原实验/补充实验覆盖。' if LANG=='zh' else 'Покрытие benchmark families в исходном и дополнительном дизайне.'
longtable('benchmark_coverage.tex',cap,'tab:appB-benchmark-coverage','L{24mm}L{38mm}L{38mm}L{34mm}L{34mm}',[T['benchmark'],'Original n','Supplement n','Original κ','Supplement κ'],rows,fontsize='7.7pt',leading='9.1pt')

# Factor coverage summary
if LANG=='zh':
    rows=[
      ['初始点/locality','原 F2：radius 变化为主；补充：DIR-E1、DIR-ONES，并加入 B-06'],
      ['初始逆 Hessian H0','原：cI 与 H* 相关 profile；补充：rotated/non-diagonal SPD，κH=1e2,1e4'],
      ['Update / weight','COMPACT_BFGS、TEACHER_EXPANDED、10 个 weighted profiles；补充聚焦 weight×line-search interaction'],
      ['步长/线搜索','FULL、FIXED grid、ARMIJO、WOLFE、STRONG_WOLFE、适用时 EXACT_REFERENCE'],
      ['Scale','原主要 n≤50（B-06≤40）；补充扩展到 n=100,200'],
      ['Conditioning','B-02 原覆盖 1e2/1e6；补充加入 1e4/1e8'],
      ['Interaction','原 F2–F5 以 OFAT 为主；补充 targeted start×H0×line-search 与 weight×line-search'],
    ]
else:
    rows=[
      ['Начальная точка / locality','Исходный F2 в основном меняет radius; дополнение: DIR-E1, DIR-ONES и B-06'],
      ['Начальное H0','Исходно: cI и профили на основе H*; дополнение: rotated/non-diagonal SPD, κH=1e2,1e4'],
      ['Update / weight','COMPACT_BFGS, TEACHER_EXPANDED, 10 weighted profiles; дополнение: weight×line-search interaction'],
      ['Шаг / line search','FULL, FIXED grid, ARMIJO, WOLFE, STRONG_WOLFE и применимый EXACT_REFERENCE'],
      ['Scale','Исходно в основном n≤50 (B-06≤40); дополнение до n=100,200'],
      ['Conditioning','Для B-02 исходно 1e2/1e6; дополнительно 1e4/1e8'],
      ['Interactions','Исходные F2–F5 в основном OFAT; targeted start×H0×line-search и weight×line-search'],
    ]
longtable('factor_coverage.tex','核心实验因素及其覆盖范围。' if LANG=='zh' else 'Ключевые факторы эксперимента и диапазоны покрытия.','tab:appB-factor-coverage','L{48mm}L{122mm}',[T['feature'],T['scope']],[[esc(a),esc(b)] for a,b in rows],fontsize='7.8pt',leading='9.2pt')

# Original family summary
fam_order=['F1','F2','F3','F4','F5','F6']
def fshort(r): return r['family'].split('-')[0]
rows=[]
for f in fam_order:
    rr=[r for r in O if fshort(r)==f]; succ=sum(str(r['success_flag']).lower()=='true' for r in rr)
    rows.append([code(f),str(len(rr)),str(succ),str(len(rr)-succ)])
longtable('original_family_summary.tex','原 246 个 scientific runs 的实验族规模。' if LANG=='zh' else 'Размер серий F1–F6 в исходных 246 scientific runs.','tab:appB-original-family','L{35mm}r r r',[T['family'],T['count'],T['success'],T['non']],rows,fontsize='8.0pt',leading='9.4pt')

# Status distributions
for name,src,label,cap in [
 ('original_status_distribution.tex',O,'tab:appB-original-status','原 246 个科学运行的 terminal distribution。' if LANG=='zh' else 'Распределение terminal status для исходных 246 запусков.'),
 ('supp_status_distribution.tex',S,'tab:appB-supp-status','105 个补充运行的 terminal distribution。' if LANG=='zh' else 'Распределение terminal status для 105 дополнительных запусков.')]:
    ctr=Counter(r['terminal_status'] for r in src)
    order=['SUCCESS_GRADIENT_NORM','SUCCESS_FUNCTION_CHANGE','DENOMINATOR_TOO_SMALL','NOT_POSITIVE_DEFINITE','NONPOSITIVE_CURVATURE','MAX_ITERATIONS','SYMMETRY_LOSS','LINE_SEARCH_TRIAL_LIMIT_REACHED','NON_DESCENT_DIRECTION']
    rows=[[code(st),str(ctr[st])] for st in order if ctr.get(st)]
    longtable(name,cap,label,'L{122mm}r',[T['status'],T['count']],rows,fontsize='8.0pt',leading='9.4pt')

# Original F1-F6 core findings
# F1
f1=[r for r in O if fshort(r)=='F1']
pairs=[(f1[i],f1[i+1]) for i in range(0,len(f1),2)]
status_match=sum(a['terminal_status']==b['terminal_status'] for a,b in pairs)
maxfd=max(abs(float(a['final_f'])-float(b['final_f'])) for a,b in pairs)
def vec(v): return ast.literal_eval(v)
def vnormdiff(a,b): return math.sqrt(sum((x-y)**2 for x,y in zip(vec(a),vec(b))))
maxxd=max(vnormdiff(a['final_x'],b['final_x']) for a,b in pairs)
# F5 metrics
f5=[r for r in O if fshort(r)=='F5']
def subset(weight): return [r for r in f5 if r['weight_id']==weight]
def med(vals): return statistics.median(vals)
w1=subset('W-0P5-1'); ws=subset('W-STD')
# F6 consistency from known grouping by benchmark_instance and result tuple
f6=[r for r in O if fshort(r)=='F6']; groups=defaultdict(list)
for r in f6: groups[r['benchmark_instance_id']].append(r)
def signature(r): return (r['terminal_status'],r['iterations'],r['function_evaluations'],r['gradient_evaluations'],r['line_search_trials'],r['final_f'],r['final_gradient_norm'],r['final_x'])
cons=sum(len({signature(r) for r in rr})==1 for rr in groups.values())
if LANG=='zh':
    rows=[
      [code('F1'),esc(f'19 对；status match {status_match}/19；max |Δf|={maxfd:.3e}；max ||Δx||2={maxxd:.6g}')],
      [code('F2'),esc('32 runs；原样本未建立跨问题统一 locality radius；补充 RQ-S1 显示 direction/local-geometry dependence')],
      [code('F3'),esc('24 runs；H0 sensitivity 为 problem-dependent；B-01/B-02 的 H*-based profiles 与 scaled-I 表现明显不同')],
      [code('F4'),esc('62 runs；B-02,n=10,κ=1e6 的 frozen fixed-alpha grid 中仅 α=1 成功；exact-reference 也成功')],
      [code('F5'),esc(f'W-0P5-1 success {sum(str(r["success_flag"]).lower()=="true" for r in w1)}/6 vs W-STD {sum(str(r["success_flag"]).lower()=="true" for r in ws)}/6；median Ng {med([int(r["gradient_evaluations"]) for r in w1]):g} vs {med([int(r["gradient_evaluations"]) for r in ws]):g}')],
      [code('F6'),esc(f'6 groups × 5 repeats；{cons}/6 groups 的 scientific outputs 在组内一致')],
    ]
else:
    rows=[
      [code('F1'),esc(f'19 пар; status match {status_match}/19; max |Δf|={maxfd:.3e}; max ||Δx||2={maxxd:.6g}')],
      [code('F2'),esc('32 runs; исходная выборка не установила единого locality radius; RQ-S1 показывает dependence on direction/local geometry')],
      [code('F3'),esc('24 runs; H0 sensitivity problem-dependent; H*-based profiles на B-01/B-02 заметно отличаются от scaled-I')],
      [code('F4'),esc('62 runs; для B-02,n=10,κ=1e6 в frozen fixed-alpha grid успешна только α=1; exact-reference также успешен')],
      [code('F5'),esc(f'W-0P5-1 success {sum(str(r["success_flag"]).lower()=="true" for r in w1)}/6 vs W-STD {sum(str(r["success_flag"]).lower()=="true" for r in ws)}/6; median Ng {med([int(r["gradient_evaluations"]) for r in w1]):g} vs {med([int(r["gradient_evaluations"]) for r in ws]):g}')],
      [code('F6'),esc(f'6 groups × 5 repeats; в {cons}/6 groups scientific outputs совпадают внутри группы')],
    ]
longtable('original_findings_summary.tex','F1–F6：由全部 246 runs 得到的核心结果。' if LANG=='zh' else 'F1–F6: ключевые результаты, полученные по всем 246 runs.','tab:appB-original-findings','L{24mm}L{146mm}',[T['family'],T['evidence']],rows,fontsize='7.6pt',leading='9.0pt')

# Representative original runs: statuses + key thesis anchors.
orig_ids=['S5R-0011','S5R-0013','S5R-0014','S5R-0015','S5R-0043','S5R-0112','S5R-0125','S5R-0141','S5R-0157','S5R-0068','S5R-0088','S5R-0120','S5R-0166','S5R-0168','S5R-0184','S5R-0220','S5R-0227','S5R-0232']
rows=[]
for rid in orig_ids:
    r=OD[rid]; f=fshort(r)
    if f=='F1': feat=r['update_implementation_id']
    elif f=='F2': feat=r['start_point_id']
    elif f=='F3': feat=r['initial_matrix_id']
    elif f=='F4': feat=r['step_line_search_id']
    elif f=='F5': feat=r['weight_id']
    else: feat='rep='+r['repetition_id']
    rows.append([code(rid),code(f),code(r['benchmark_instance_id']),code(feat),code(r['terminal_status']),intval(r['iterations']),intval(r['gradient_evaluations'])])
longtable('original_representative_runs.tex','原实验代表性运行：覆盖 F1–F6、全部主要终止类型及正文关键 anchor。' if LANG=='zh' else 'Репрезентативные исходные запуски: F1–F6, основные terminal types и ключевые anchors.','tab:appB-original-representative','L{17mm}L{10mm}L{30mm}L{30mm}L{42mm}L{13mm}L{13mm}',[T['run'],T['family'],T['benchmark'],T['feature'],T['status'],T['k'],T['ng']],rows,fontsize='7.0pt',leading='8.4pt',tabcolsep='1.2pt')

# Reproduction verification summary
if LANG=='zh':
    rows=[['覆盖（参考 Linux 平台）','246/246 scientific runs'],['Terminal status','246/246 exact'],['Iteration / evaluation counts','246/246 exact'],['Scientific numeric fields','246/246 match'],['Scientific mismatch','0'],['本次观测最大绝对数值差','0（不等价于跨机器 bitwise identity）']]
else:
    rows=[['Охват (эталонная Linux-среда)','246/246 scientific runs'],['Terminal status','246/246 exact'],['Iteration / evaluation counts','246/246 exact'],['Scientific numeric fields','246/246 match'],['Scientific mismatch','0'],['Макс. наблюдаемая абсолютная разность','0 (не означает bitwise identity на других машинах)']]
longtable('reproduction_summary.tex','原 246-run 参考 Linux 平台复现摘要。' if LANG=='zh' else 'Сводка воспроизведения исходных 246 runs в эталонной Linux-среде.','tab:appB-reproduction','L{72mm}L{98mm}',[T['metric'],T['value']],[[esc(a),esc(b)] for a,b in rows],fontsize='8.0pt',leading='9.4pt')

# Supplementary family summary
rows=[]
rqmap={'SF-S1-LOCAL-DIRECTION':'RQ-S1','SF-S2-H0-ANISOTROPY':'RQ-S2','SF-S3-SCALE':'RQ-S3','SF-S4-CONDITIONING':'RQ-S4','SF-S5-FACTOR-INTERACTION':'RQ-S5','SF-S6-WEIGHT-LS-INTERACTION':'RQ-S6'}
for r in SF:
    rows.append([code(r['supp_family']),code(rqmap.get(r['supp_family'],'—')),intval(r['planned']),intval(r['success']),intval(r['non_success'])])
longtable('supp_family_summary.tex','补充实验六个 families 的执行结果。' if LANG=='zh' else 'Результаты шести серий supplementary experiments.','tab:appB-supp-family','L{62mm}L{25mm}r r r',[T['family'],T['rq'],T['count'],T['success'],T['non']],rows,fontsize='7.5pt',leading='8.9pt')

# Representative supplementary runs (2-3 per RQ, selected as concrete counterexamples/edge cases)
supp_ids=['SUPP-R0001','SUPP-R0002','SUPP-R0051','SUPP-R0052','SUPP-R0065','SUPP-R0071','SUPP-R0072','SUPP-R0073','SUPP-R0074','SUPP-R0076','SUPP-R0081','SUPP-R0082','SUPP-R0084','SUPP-R0086','SUPP-R0088','SUPP-R0096','SUPP-R0098','SUPP-R0100','SUPP-R0101','SUPP-R0103','SUPP-R0104','SUPP-R0105']
rows=[]
for rid in supp_ids:
    r=SD[rid]
    feat=''
    rq=r['research_question_id']
    if rq=='RQ-S1': feat=f"{r['start_direction_id']}, r={r['start_radius']}"
    elif rq=='RQ-S2': feat=r['initial_matrix_id']
    elif rq=='RQ-S3': feat='n='+r['dimension']
    elif rq=='RQ-S4': feat='kappa='+r['condition_number']
    elif rq=='RQ-S5': feat=f"{r['start_direction_id']}/{r['initial_matrix_id']}/{r['step_line_search_id']}"
    else: feat=f"{r['weight_id']}/{r['step_line_search_id']}"
    rows.append([code(rid),code(rq),code(r['benchmark_id']),esc(feat),code(r['terminal_status']),intval(r['gradient_evaluations'])])
longtable('supp_representative_runs.tex','补充实验代表性运行：覆盖 RQ-S1–RQ-S6 的关键反例、边界与交互。' if LANG=='zh' else 'Репрезентативные supplementary runs: ключевые контрпримеры, границы и interactions для RQ-S1–RQ-S6.','tab:appB-supp-representative','L{20mm}L{18mm}L{16mm}L{42mm}L{45mm}L{14mm}',[T['run'],T['rq'],T['benchmark'],T['feature'],T['status'],T['ng']],rows,fontsize='7.0pt',leading='8.4pt',tabcolsep='1.2pt')

# RQ-S1 selected examples, summary counts retained in text.
sel=['SUPP-R0001','SUPP-R0002','SUPP-R0003','SUPP-R0004','SUPP-R0017','SUPP-R0018','SUPP-R0031','SUPP-R0032','SUPP-R0051','SUPP-R0052','SUPP-R0053','SUPP-R0054']
rows=[]
for rid in sel:
    r=SD[rid]
    rows.append([code(rid),code(r['benchmark_id']),num(r['start_radius'],3),code(r['start_direction_id']),code(r['terminal_status'])])
longtable('rq_s1_representative.tex','RQ-S1 代表性方向敏感性结果（完整 54-run 数据见电子 CSV）。' if LANG=='zh' else 'RQ-S1: репрезентативные результаты чувствительности к направлению (полные 54 runs в CSV).','tab:appB-rq-s1-rep','L{20mm}L{16mm}L{20mm}L{28mm}L{64mm}',[T['run'],T['benchmark'],T['radius'],T['dir'],T['status']],rows,fontsize='7.2pt',leading='8.6pt')

# RQ-S2 selected comparison cells with identity anchors from comparison_anchor
s2=[r for r in S if r['research_question_id']=='RQ-S2']; g=defaultdict(dict)
for r in s2: g[r['comparison_anchor']][r['initial_matrix_id']]=r
# choose B01, two B04 basins incl success, B06
chosen=[]
for anchor,d in g.items():
    b=OD[anchor]['benchmark_id']; start=OD[anchor]['start_point_id']
    if b=='B-01' or b=='B-06' or (b=='B-04' and start in {'P-B04-M2-L2','P-B04-M3-L2'}): chosen.append((anchor,d))
rows=[]
for anchor,d in chosen:
    ar=OD[anchor]; k2=next((v for k,v in d.items() if k.endswith('K1E2')),None); k4=next((v for k,v in d.items() if k.endswith('K1E4')),None)
    rows.append([code(anchor),code(ar['benchmark_id']),code(ar['terminal_status']),code(k2['terminal_status']) if k2 else '—',code(k4['terminal_status']) if k4 else '—'])
longtable('rq_s2_representative.tex','RQ-S2 代表性 H0 对照（完整 18-run 数据见电子 CSV）。' if LANG=='zh' else 'RQ-S2: репрезентативное сравнение H0 (полные 18 runs в CSV).','tab:appB-rq-s2-rep','L{23mm}L{18mm}L{46mm}L{42mm}L{42mm}',[T['anchor'],T['benchmark'],T['identity'],T['k1e2'],T['k1e4']],rows,fontsize='7.0pt',leading='8.4pt')

# RQ-S3 all 8; compact portrait
rows=[]
for r in [x for x in S if x['research_question_id']=='RQ-S3']:
    rows.append([code(r['supp_run_id']),code(r['benchmark_id']),intval(r['dimension']),code(r['terminal_status']),intval(r['gradient_evaluations']),num(r['wall_elapsed_seconds'],4),num(r['process_peak_rss_mb'],4)])
longtable('rq_s3.tex','RQ-S3：n=100/200 scale supplement（8 runs）。' if LANG=='zh' else 'RQ-S3: scale supplement n=100/200 (8 runs).','tab:appB-rq-s3','L{22mm}L{18mm}r L{48mm}r L{28mm}L{30mm}',[T['run'],T['benchmark'],T['n'],T['status'],T['ng'],T['time'],T['rss']],rows,fontsize='6.9pt',leading='8.2pt',tabcolsep='1.1pt')

# RQ-S4 combined original anchors + 4 supplemental
pts=[]
for rid,k in [('S5R-0019',1e2),('S5R-0021',1e6),('S5R-0023',1e2),('S5R-0025',1e6)]:
    r=OD[rid]; pts.append((int(r['dimension']),k,rid,r['terminal_status'],r['gradient_evaluations']))
for r in S:
    if r['research_question_id']=='RQ-S4': pts.append((int(r['dimension']),float(r['condition_number']),r['supp_run_id'],r['terminal_status'],r['gradient_evaluations']))
pts.sort(key=lambda x:(x[0],x[1]))
rows=[]
for n,k,rid,st,ng in pts:
    exp=int(round(math.log10(k))) if k>0 else 0; klab=rf'\(\displaystyle 10^{{{exp}}}\)' if k!=1 else '1'
    rows.append([str(n),klab,code(rid),code(st),intval(ng)])
longtable('rq_s4.tex','RQ-S4：B-02 conditioning sequence。' if LANG=='zh' else 'RQ-S4: последовательность conditioning для B-02.','tab:appB-rq-s4','r L{25mm}L{27mm}L{78mm}r',[T['n'],T['kappa'],T['run'],T['status'],T['ng']],rows,fontsize='7.3pt',leading='8.7pt')

# RQ-S5 summary
rows=[[code('START'),'5/12','3/12'],[code('H0'),'6/12','3/12'],[code('LINE_SEARCH'),'2/12','1/12']]
longtable('rq_s5.tex','RQ-S5：36 个 controlled contrasts 的 interaction summary。' if LANG=='zh' else 'RQ-S5: interaction summary для 36 controlled contrasts.','tab:appB-rq-s5','L{60mm}L{55mm}L{55mm}',[T['factor'],T['changed'],T['schanged']],rows,fontsize='8.0pt',leading='9.4pt')

# RQ-S6 all 6 new runs with anchors
s6=[r for r in S if r['research_question_id']=='RQ-S6']
rows=[]
for r in s6:
    ar=OD[r['comparison_anchor']]
    rows.append([code(r['benchmark_id']),code(r['weight_id']),code(ar['terminal_status']),code(r['terminal_status']),intval(ar['gradient_evaluations']),intval(r['gradient_evaluations'])])
longtable('rq_s6.tex','RQ-S6：weight × line-search paired comparison（6 new runs）。' if LANG=='zh' else 'RQ-S6: парное сравнение weight × line-search (6 new runs).','tab:appB-rq-s6','L{18mm}L{30mm}L{48mm}L{48mm}r r',[T['benchmark'],T['weight'],T['from'],T['to'],T['gfrom'],T['gto']],rows,fontsize='7.0pt',leading='8.4pt',tabcolsep='1.1pt')

# F4 bridge all 6 existing anchors; inspect actual fieldnames flexibly
rows=[]
for r in F4:
    # one row per comparison_cell usually already has both modes/statuses
    vals=[r.get(k,'') for k in r]
    # use known fields by introspection names
    bench=r.get('benchmark_instance_id') or r.get('benchmark_id') or r.get('comparison_cell_id','')
    sw=r.get('strong_wolfe_terminal_status') or r.get('strong_wolfe_status') or r.get('terminal_status_strong_wolfe') or r.get('STRONG_WOLFE_terminal_status') or ''
    w=r.get('wolfe_terminal_status') or r.get('wolfe_status') or r.get('terminal_status_wolfe') or r.get('WOLFE_terminal_status') or ''
    # if bridge file is long form, handle line_search_mode
    if not sw and 'line_search_mode' in r:
        continue
    if sw or w:
        rows.append([code(bench),code(sw),code(w)])
# fallback reconstruct from original if needed
if not rows:
    reps=['BI-B01-N010','BI-B02-N010-K1E6','BI-B03-N002','BI-B04-N002','BI-B05-N010','BI-B06-N020']
    for bi in reps:
        rr=[r for r in O if fshort(r)=='F4' and r['benchmark_instance_id']==bi]
        w=next((x for x in rr if x['step_line_search_id']=='LS-WOLFE'),None)
        # strong-wolfe anchor elsewhere with same benchmark/start/H0/update/weight
        sw=next((x for x in O if x['benchmark_instance_id']==bi and x['step_line_search_id']=='LS-STRONG-WOLFE' and x['initial_matrix_id']=='M-I-1' and x['update_implementation_id']=='COMPACT_BFGS'),None)
        if w and sw: rows.append([code(bi),code(sw['terminal_status']),code(w['terminal_status'])])
longtable('f4_bridge.tex',r'F4：既有 STRONG\_WOLFE anchors 与 WOLFE 的 zero-new-run bridge。' if LANG=='zh' else r'F4: zero-new-run bridge между существующими STRONG\_WOLFE anchors и WOLFE.','tab:appB-f4-bridge','L{55mm}L{50mm}L{50mm}',[T['benchmark'],T['from'],T['to']],rows,fontsize='7.2pt',leading='8.6pt')

# Electronic file index; full data row counts
idx=[
 ('original_246_reference_summary.csv',len(O),'246 original runs: complete scalar configuration/result/diagnostic summary'),
 ('supplementary_105_master.csv',len(S),'105 supplementary runs: configuration, results, diagnostics, purpose/notes'),
 ('supplementary_family_summary.csv',len(SF),'supplementary family aggregate'),
 ('supplementary_failure_analysis.csv',len(readcsv('supplementary_failure_analysis.csv')),'non-success scientific outcomes and diagnostics'),
 ('supplementary_rq_findings.csv',len(RQ),'RQ-S1--RQ-S6 findings and thesis-impact flags'),
 ('f4_strong_wolfe_analysis_bridge.csv',len(F4),'existing-data F4 STRONG_WOLFE/WOLFE bridge'),
 ('field_dictionary.md','—','field definitions and interpretation'),
]
rows=[[code(a),str(b),esc(c)] for a,b,c in idx]
longtable('electronic_data_index.tex','完整电子数据索引（PDF 仅保留核心/代表性内容）。' if LANG=='zh' else 'Индекс полных электронных данных (PDF содержит только ключевые/репрезентативные данные).','tab:appB-electronic-index','L{60mm}L{17mm}L{78mm}',[T['file'],T['rows'],T['role']],rows,fontsize='7.5pt',leading='8.9pt')

print(f'generated {len(list(OUT.glob("*.tex")))} compact portrait tables in {OUT}')
