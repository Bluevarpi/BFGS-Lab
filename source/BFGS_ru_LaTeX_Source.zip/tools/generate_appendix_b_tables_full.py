#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, math, re
from pathlib import Path
from collections import Counter, defaultdict

PARSER=argparse.ArgumentParser()
PARSER.add_argument('--lang',choices=['zh','ru'],required=True)
PARSER.add_argument('--data-dir',default='data/appendix_b_data')
PARSER.add_argument('--out-dir',default='generated_appendix_b')
args=PARSER.parse_args()
ROOT=Path.cwd(); DATA=(ROOT/args.data_dir); OUT=(ROOT/args.out_dir); OUT.mkdir(parents=True,exist_ok=True)

LANG=args.lang
T={
'zh':{
'continued':'（续）','run':'Run','scope':'类别','family':'实验族','experiment':'实验单元','benchmark':'Benchmark','n':'n','class':'分类',
'status':'终止状态','success':'成功','it':'迭代','nf':'Nf','ng':'Ng','ls':'LS trials','finalf':'最终 f','grad':'最终 ||g||',
'x0':'x0 ID','h0':'H0 ID','update':'更新','weight':'权重','step':'步长/线搜索','rq':'RQ','kappa':'条件数','dir':'方向','radius':'半径','anchor':'对照 anchor',
'kappah':r'\(\displaystyle \kappa_H\)','tol':'容差配置','budget':'预算配置','stepnorm':'最终步长','secant':'割线残差','sym':'对称误差','mineig':'最小特征值','xerr':'x 误差','ferr':'f 误差','last':'最后有效迭代','termrow':'终端行状态','time':'时间/s','rss':'峰值 RSS/MB',
'source':'来源','count':'使用次数','profile':'配置','notes':'说明','identity':'Identity H0','k1e2':'SPD 1e2','k1e4':'SPD 1e4','orig':'原方向/anchor','e1':'DIR-E1','ones':'DIR-ONES','change':'比较',
'factor':'因素','statuschanged':'status 改变','successchanged':'success 改变','total':'对比数','from':r'STRONG\_WOLFE','to':'WOLFE','gfrom':'Ng(SW)','gto':'Ng(W)','secfrom':'Secant(SW)','secto':'Secant(W)',
'purpose':'用途/范围','order':'顺序','expid':'Experiment ID','rqids':'RQ IDs','rep':'重复','termclass':'终止类','accepted':'接受步','nh':'Nh','termcurv':'终端曲率','termsec':'终端割线残差','termsym':'终端后对称误差','termeig':'终端后最小特征值','seed':'Seed','validation':'技术验证；不计入科学结果','scientific':'科学实验','na':'--','yes':'是','no':'否'
},
'ru':{
'continued':'(продолжение)','run':'Run','scope':'Тип','family':'Серия','experiment':'Ячейка','benchmark':'Benchmark','n':'n','class':'Класс',
'status':'Терминальный статус','success':'Успех','it':'Итерации','nf':'Nf','ng':'Ng','ls':'LS trials','finalf':'Итоговое f','grad':'Итоговая ||g||',
'x0':'ID x0','h0':'ID H0','update':'Обновление','weight':'Вес','step':'Шаг/поиск','rq':'RQ','kappa':'Число обусловл.','dir':'Направление','radius':'Радиус','anchor':'Опорный запуск',
'kappah':r'\(\displaystyle \kappa_H\)','tol':'Профиль допусков','budget':'Профиль бюджета','stepnorm':'Итоговый шаг','secant':'Секущая невязка','sym':'Ошибка симм.','mineig':'Мин. собств. знач.','xerr':'Ошибка x','ferr':'Ошибка f','last':'Последняя валид. ит.','termrow':'Статус термин. строки','time':'Время, с','rss':'Peak RSS, MB',
'source':'Источник','count':'Число','profile':'Профиль','notes':'Примечание','identity':'Identity H0','k1e2':'SPD 1e2','k1e4':'SPD 1e4','orig':'Исходное направление/anchor','e1':'DIR-E1','ones':'DIR-ONES','change':'Сравнение',
'factor':'Фактор','statuschanged':'Изменение status','successchanged':'Изменение success','total':'Число сравнений','from':r'STRONG\_WOLFE','to':'WOLFE','gfrom':'Ng(SW)','gto':'Ng(W)','secfrom':'Secant(SW)','secto':'Secant(W)',
'purpose':'Назначение/область','order':'Порядок','expid':'Experiment ID','rqids':'RQ IDs','rep':'Повтор','termclass':'Класс завершения','accepted':'Принятые шаги','nh':'Nh','termcurv':'Термин. кривизна','termsec':'Термин. секущая невязка','termsym':'Ошибка симм. после terminal update','termeig':'Мин. собств. знач. после terminal update','seed':'Seed','validation':'Техническая валидация; не входит в научные результаты','scientific':'Научный эксперимент','na':'--','yes':'да','no':'нет'
}}
t=T[LANG]

def read_csv(name):
    with open(DATA/name,encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
O=read_csv('original_246_reference_summary.csv')
S=read_csv('supplementary_105_master.csv')
F4=read_csv('f4_strong_wolfe_analysis_bridge.csv')
FAM=read_csv('supplementary_family_summary.csv')
OD={r['planned_run_id']:r for r in O}

def missing(x): return x is None or str(x).strip()=='' or str(x).strip().lower() in {'nan','none','na'}
def code(x):
    if missing(x): return r'\textemdash'
    return r'\BFGSCode{' + str(x).replace('}','') + '}'
def esc(x):
    if missing(x): return r'\textemdash'
    s=str(x)
    for a,b in [('&',r'\&'),('%',r'\%'),('#',r'\#'),('_',r'\_')]: s=s.replace(a,b)
    return s
def boolmark(x):
    s=str(x).strip().lower(); return t['yes'] if s=='true' else t['no'] if s=='false' else r'\textemdash'
def num(x, digits=4):
    if missing(x): return r'\textemdash'
    try: v=float(x)
    except: return esc(x)
    if math.isnan(v): return r'\textemdash'
    if abs(v) < 1e-300: return r'\(\displaystyle 0\)'
    if abs(v)>=1e4 or abs(v)<1e-3:
        e=int(math.floor(math.log10(abs(v))))
        m=v/(10**e)
        return rf'\(\displaystyle {m:.{digits}g}\times 10^{{{e}}}\)'
    if float(v).is_integer() and abs(v)<1e12: return str(int(v))
    return f'{v:.{digits}g}'
def intval(x):
    if missing(x): return r'\textemdash'
    try: return str(int(float(x)))
    except: return esc(x)
def condition_label(x):
    if missing(x): return r'\textemdash'
    v=float(x)
    if v==1: return r'\(\displaystyle 1\)'
    e=round(math.log10(v))
    if abs(v-10**e)<1e-8*max(1,v): return rf'\(\displaystyle 10^{{{e}}}\)'
    return num(v)

def longtable(filename, caption, label, columns, headers, rows, fontsize='7.0pt', leading='8.2pt', tabcolsep='2.4pt'):
    p=OUT/filename
    with p.open('w',encoding='utf-8') as f:
        f.write('\\begin{landscape}\n\\begingroup\n')
        f.write(rf'\fontsize{{{fontsize}}}{{{leading}}}\selectfont'+'\n')
        f.write(rf'\setlength{{\tabcolsep}}{{{tabcolsep}}}'+'\n')
        f.write(r'\renewcommand{\arraystretch}{1.12}'+'\n')
        f.write(rf'\begin{{longtable}}{{@{{}}{columns}@{{}}}}'+'\n')
        f.write(rf'\caption{{{caption}}}\label{{{label}}}\\'+'\n')
        f.write(r'\toprule '+' & '.join(headers)+r' \\'+'\n\\midrule\n\\endfirsthead\n')
        f.write(rf'\multicolumn{{{len(headers)}}}{{c}}{{\small\itshape {caption} {t["continued"]}}}\\'+'\n')
        f.write(r'\toprule '+' & '.join(headers)+r' \\'+'\n\\midrule\n\\endhead\n')
        f.write(rf'\midrule\multicolumn{{{len(headers)}}}{{r}}{{\scriptsize {t["continued"]}}}\\\endfoot'+'\n')
        f.write(r'\bottomrule\endlastfoot'+'\n')
        for row in rows: f.write(' & '.join(row)+r' \\'+'\n')
        f.write('\\end{longtable}\n\\endgroup\n\\end{landscape}\n')

# 256 planned design index
rows=[]
for i in range(1,11):
    rid=f'S5R-{i:04d}'
    rows.append([code(rid),str(i),code('VALIDATION_ONLY'),r'\textemdash',r'\textemdash',r'\textemdash',r'\textemdash',esc(t['validation'])])
for r in O:
    rows.append([code(r['planned_run_id']),intval(r['execution_order_index']),code('SCIENTIFIC'),code(r['family']),code(r['experiment_id']),code(r['benchmark_instance_id']),intval(r['dimension']),esc(t['scientific'])])
longtable('planned_256_design.tex',
          '原 256 个 planned cells 的设计索引。' if LANG=='zh' else 'Индекс исходных 256 плановых ячеек.',
          'tab:appB-planned-256','L{18mm}r L{24mm}L{30mm}L{42mm}L{39mm}r L{45mm}',
          [t['run'],r'\#',t['scope'],t['family'],t['experiment'],t['benchmark'],t['n'],t['purpose']],rows,fontsize='6.8pt',leading='8.0pt')

# Benchmark registry
reg={}
for source,rowsrc in [('ORIGINAL',O),('SUPPLEMENTARY',S)]:
    for r in rowsrc:
        bid=r['benchmark_instance_id']; key=(source,bid)
        cond=r.get('condition_number','')
        if source=='ORIGINAL' and missing(cond):
            m=re.search(r'-K1E(\d+)$',bid)
            if m: cond=str(10**int(m.group(1)))
            elif bid.endswith('-K1'): cond='1'
        reg[key]=(source,r['benchmark_id'],bid,r['dimension'],cond)
rows=[[code(a),code(b),code(c),intval(d),condition_label(e)] for (a,c),(a,b,c,d,e) in sorted(reg.items())]
longtable('benchmark_registry.tex','Benchmark / problem-instance registry.' if LANG=='ru' else 'Benchmark / problem-instance registry。','tab:appB-benchmark-reg','L{27mm}L{20mm}L{70mm}r L{32mm}',[t['source'],t['benchmark'],'Instance',t['n'],t['kappa']],rows,fontsize='7.2pt',leading='8.5pt')

# Start registry, aggregate counts
startmap={}
for source,rowsrc in [('ORIGINAL',O),('SUPPLEMENTARY',S)]:
    for r in rowsrc:
        sid=r['start_point_id']; key=(source,sid)
        d=r.get('start_direction_id',''); rad=r.get('start_radius','')
        if key not in startmap: startmap[key]=[source,sid,r['benchmark_id'],d,rad,0]
        startmap[key][-1]+=1
rows=[]
for k,v in sorted(startmap.items()):
    rows.append([code(v[0]),code(v[1]),code(v[2]),code(v[3]),num(v[4],3),str(v[5])])
longtable('start_registry.tex','初始点与 locality 参数 registry。' if LANG=='zh' else 'Реестр начальных точек и параметров locality.','tab:appB-start-reg','L{27mm}L{82mm}L{20mm}L{31mm}L{24mm}r',[t['source'],t['x0'],t['benchmark'],t['dir'],t['radius'],t['count']],rows,fontsize='6.8pt',leading='8.0pt')

# H0 registry
hmap={}
for source,rowsrc in [('ORIGINAL',O),('SUPPLEMENTARY',S)]:
    for r in rowsrc:
        hid=r['initial_matrix_id']; k=(source,hid)
        kh=r.get('initial_matrix_condition_number','')
        if k not in hmap: hmap[k]=[source,hid,kh,0]
        hmap[k][-1]+=1
rows=[[code(v[0]),code(v[1]),condition_label(v[2]),str(v[3])] for k,v in sorted(hmap.items())]
longtable('h0_registry.tex','初始逆 Hessian 配置 registry。' if LANG=='zh' else 'Реестр конфигураций начального приближения обратной матрицы Гессе.','tab:appB-h0-reg','L{30mm}L{105mm}L{40mm}r',[t['source'],t['h0'],t['kappah'],t['count']],rows,fontsize='7.2pt',leading='8.5pt')

# Update/weight and line-search registries
for fname,key1,key2,cap,label in [
 ('update_weight_registry.tex','update_implementation_id','weight_id','更新/权重组合 registry。' if LANG=='zh' else 'Реестр сочетаний обновления и весов.','tab:appB-update-weight'),
 ('line_search_registry.tex','step_line_search_id',None,'步长与线搜索 registry。' if LANG=='zh' else 'Реестр способов выбора шага и линейного поиска.','tab:appB-ls-reg')]:
    ctr=Counter()
    for source,rowsrc in [('ORIGINAL',O),('SUPPLEMENTARY',S)]:
        for r in rowsrc:
            val=(r[key1],r[key2]) if key2 else (r[key1],)
            ctr[(source,)+val]+=1
    rows=[]
    for k,c in sorted(ctr.items()):
        if key2: rows.append([code(k[0]),code(k[1]),code(k[2]),str(c)])
        else: rows.append([code(k[0]),code(k[1]),str(c)])
    if key2: longtable(fname,cap,label,'L{32mm}L{85mm}L{65mm}r',[t['source'],t['update'],t['weight'],t['count']],rows,fontsize='7.2pt',leading='8.5pt')
    else: longtable(fname,cap,label,'L{35mm}L{120mm}r',[t['source'],t['step'],t['count']],rows,fontsize='7.2pt',leading='8.5pt')

# profiles registry
ctr=Counter()
for source,rowsrc in [('ORIGINAL',O),('SUPPLEMENTARY',S)]:
    for r in rowsrc: ctr[(source,r['tolerance_profile_id'],r['budget_profile_id'])]+=1
rows=[[code(a),code(b),code(c),str(n)] for (a,b,c),n in sorted(ctr.items())]
longtable('profile_registry.tex','Tolerance / budget profile registry.' if LANG=='ru' else 'Tolerance / budget profile registry。','tab:appB-profile-reg','L{35mm}L{70mm}L{70mm}r',[t['source'],t['tol'],t['budget'],t['count']],rows,fontsize='7.2pt',leading='8.5pt')

# original configuration, split into two Run-ID-linked tables for readability
rows=[]
for r in O:
    rows.append([code(r['planned_run_id']),code(r['family']),code(r['benchmark_instance_id']),intval(r['dimension']),code(r['start_point_id']),code(r['classification'])])
longtable('original_246_config_a.tex','原 246 个 scientific runs：问题与初始点配置。' if LANG=='zh' else 'Исходные 246 scientific runs: задача и начальная точка.','tab:appB-original-246-config-a','L{20mm}L{32mm}L{55mm}r L{85mm}L{30mm}',[t['run'],t['family'],t['benchmark'],t['n'],t['x0'],t['class']],rows,fontsize='6.7pt',leading='7.9pt',tabcolsep='1.7pt')
rows=[]
for r in O:
    rows.append([code(r['planned_run_id']),code(r['initial_matrix_id']),code(r['update_implementation_id']),code(r['weight_id']),code(r['step_line_search_id'])])
longtable('original_246_config_b.tex','原 246 个 scientific runs：H0、更新、权重与 globalization 配置。' if LANG=='zh' else 'Исходные 246 scientific runs: H0, обновление, вес и globalization.','tab:appB-original-246-config-b','L{20mm}L{70mm}L{55mm}L{40mm}L{55mm}',[t['run'],t['h0'],t['update'],t['weight'],t['step']],rows,fontsize='6.7pt',leading='7.9pt',tabcolsep='1.7pt')

# original results
rows=[]
for r in O:
    rows.append([code(r['planned_run_id']),code(r['terminal_status']),boolmark(r['success_flag']),intval(r['iterations']),intval(r['function_evaluations']),intval(r['gradient_evaluations']),intval(r['line_search_trials']),num(r['final_f']),num(r['final_gradient_norm'])])
longtable('original_246_results.tex','原 246 个 scientific runs：terminal / efficiency results。' if LANG=='zh' else 'Исходные 246 scientific runs: terminal / efficiency results.','tab:appB-original-246-results','L{19mm}L{58mm}L{18mm}r r r r L{30mm}L{30mm}',[t['run'],t['status'],t['success'],t['it'],t['nf'],t['ng'],t['ls'],t['finalf'],t['grad']],rows,fontsize='6.8pt',leading='8.0pt')

# original diagnostics, split into structural and target/terminal diagnostics
rows=[]
for r in O:
    rows.append([code(r['planned_run_id']),num(r['final_step_norm']),num(r['secant_residual']),num(r['symmetry_error']),num(r['minimum_eigenvalue'])])
longtable('original_246_diagnostics_a.tex','原 246 个 scientific runs：结构性 numerical diagnostics。' if LANG=='zh' else 'Исходные 246 scientific runs: структурные numerical diagnostics.','tab:appB-original-246-diag-a','L{20mm}L{45mm}L{45mm}L{45mm}L{45mm}',[t['run'],t['stepnorm'],t['secant'],t['sym'],t['mineig']],rows,fontsize='6.9pt',leading='8.1pt',tabcolsep='1.8pt')
rows=[]
for r in O:
    rows.append([code(r['planned_run_id']),num(r['known_x_error']),num(r['known_f_error']),intval(r['last_valid_iteration']),code(r['terminal_row_status'])])
longtable('original_246_diagnostics_b.tex','原 246 个 scientific runs：目标误差与 terminal-row diagnostics。' if LANG=='zh' else 'Исходные 246 scientific runs: ошибки относительно цели и terminal-row diagnostics.','tab:appB-original-246-diag-b','L{20mm}L{45mm}L{45mm}L{25mm}L{90mm}',[t['run'],t['xerr'],t['ferr'],t['last'],t['termrow']],rows,fontsize='6.9pt',leading='8.1pt',tabcolsep='1.8pt')

# supplementary configuration split into four Run-ID-linked tables
rows=[]
for r in S:
    rows.append([code(r['supp_run_id']),code(r['research_question_id']),code(r['supp_family']),code(r['benchmark_instance_id']),intval(r['dimension']),condition_label(r['condition_number'])])
longtable('supp_105_config_a.tex','105 个 supplementary runs：RQ、实验族、问题与维数配置。' if LANG=='zh' else '105 supplementary runs: RQ, серия, задача и размерность.','tab:appB-supp-config-a','L{20mm}L{20mm}L{55mm}L{65mm}r L{30mm}',[t['run'],t['rq'],t['family'],t['benchmark'],t['n'],t['kappa']],rows,fontsize='6.8pt',leading='8.0pt',tabcolsep='1.8pt')
rows=[]
for r in S:
    rows.append([code(r['supp_run_id']),code(r['start_direction_id']),num(r['start_radius'],3),code(r['start_point_id'])])
longtable('supp_105_config_b.tex','105 个 supplementary runs：方向、半径与初始点配置。' if LANG=='zh' else '105 supplementary runs: направление, радиус и начальная точка.','tab:appB-supp-config-b','L{20mm}L{35mm}L{25mm}L{145mm}',[t['run'],t['dir'],t['radius'],t['x0']],rows,fontsize='6.8pt',leading='8.0pt',tabcolsep='1.8pt')
rows=[]
for r in S:
    rows.append([code(r['supp_run_id']),code(r['initial_matrix_id']),condition_label(r['initial_matrix_condition_number']),code(r['update_implementation_id']),code(r['weight_id']),code(r['step_line_search_id'])])
longtable('supp_105_config_c.tex','105 个 supplementary runs：H0、更新、权重与 globalization 配置。' if LANG=='zh' else '105 supplementary runs: H0, обновление, вес и globalization.','tab:appB-supp-config-c','L{20mm}L{58mm}L{28mm}L{50mm}L{36mm}L{50mm}',[t['run'],t['h0'],t['kappah'],t['update'],t['weight'],t['step']],rows,fontsize='6.6pt',leading='7.8pt',tabcolsep='1.7pt')
rows=[]
for r in S:
    rows.append([code(r['supp_run_id']),code(r['tolerance_profile_id']),code(r['budget_profile_id']),code(r['comparison_anchor'])])
longtable('supp_105_config_d.tex','105 个 supplementary runs：tolerance、budget 与 comparison anchor。' if LANG=='zh' else '105 supplementary runs: tolerance, budget и comparison anchor.','tab:appB-supp-config-d','L{20mm}L{55mm}L{55mm}L{110mm}',[t['run'],t['tol'],t['budget'],t['anchor']],rows,fontsize='6.7pt',leading='7.9pt',tabcolsep='1.7pt')
rows=[]
for r in S:
    rows.append([code(r['supp_run_id']),code(r['terminal_status']),boolmark(r['success_flag']),intval(r['iterations']),intval(r['function_evaluations']),intval(r['gradient_evaluations']),intval(r['line_search_trials']),num(r['final_f']),num(r['final_gradient_norm'])])
longtable('supp_105_results.tex','105 个 supplementary runs：terminal / efficiency results。' if LANG=='zh' else '105 supplementary runs: terminal / efficiency results.','tab:appB-supp-results','L{20mm}L{58mm}L{18mm}r r r r L{30mm}L{30mm}',[t['run'],t['status'],t['success'],t['it'],t['nf'],t['ng'],t['ls'],t['finalf'],t['grad']],rows,fontsize='6.8pt',leading='8.0pt')
rows=[]
for r in S:
    rows.append([code(r['supp_run_id']),num(r['secant_residual']),num(r['symmetry_error']),num(r['minimum_eigenvalue'])])
longtable('supp_105_diagnostics_a.tex','105 个 supplementary runs：结构性 diagnostics。' if LANG=='zh' else '105 supplementary runs: структурные diagnostics.','tab:appB-supp-diag-a','L{20mm}L{55mm}L{55mm}L{55mm}',[t['run'],t['secant'],t['sym'],t['mineig']],rows,fontsize='7.0pt',leading='8.2pt',tabcolsep='1.8pt')
rows=[]
for r in S:
    rows.append([code(r['supp_run_id']),num(r['known_x_error']),num(r['known_f_error']),num(r['wall_elapsed_seconds'],4),num(r['process_peak_rss_mb'],4)])
longtable('supp_105_diagnostics_b.tex','105 个 supplementary runs：目标误差与当前环境性能观测。' if LANG=='zh' else '105 supplementary runs: ошибки относительно цели и наблюдаемая производительность в текущей среде.','tab:appB-supp-diag-b','L{20mm}L{55mm}L{55mm}L{40mm}L{40mm}',[t['run'],t['xerr'],t['ferr'],t['time'],t['rss']],rows,fontsize='7.0pt',leading='8.2pt',tabcolsep='1.8pt')

# supplementary family summary
rows=[]
for r in FAM:
    rows.append([code(r['supp_family']),intval(r['planned']),intval(r['valid']),intval(r['success']),intval(r['non_success']),num(r['median_gradient_evaluations']),num(r['median_line_search_trials']),num(r['max_process_peak_rss_mb'])])
longtable('supp_family_summary.tex','Supplementary family summary.' if LANG=='ru' else 'Supplementary family summary。','tab:appB-supp-family','L{58mm}r r r r L{34mm}L{34mm}L{34mm}',[t['family'],'Planned','Valid','Success','Non-success','Median Ng','Median LS','Max RSS'],rows,fontsize='7.0pt',leading='8.2pt')

# RQ-S1 grouped comparison
s1=[r for r in S if r['research_question_id']=='RQ-S1']
g=defaultdict(dict)
for r in s1:
    key=(r['benchmark_id'],r['start_radius'],r['comparison_anchor'])
    g[key][r['start_direction_id']]=r
rows=[]
for (b,rad,anchor),d in sorted(g.items(), key=lambda x:(x[0][0],float(x[0][1]),x[0][2])):
    direct='NO_ORIGINAL_F2_B06_CELL' not in anchor
    arid=anchor.split(';')[0]
    ar=OD.get(arid) if direct else None
    orig=code(ar['terminal_status']) if ar else (esc('无原 F2 cell') if LANG=='zh' else esc('нет исходной F2-ячейки'))
    e=d.get('DIR-E1'); one=d.get('DIR-ONES')
    eout=code(e['terminal_status']) if e else r'\textemdash'; oout=code(one['terminal_status']) if one else r'\textemdash'
    rows.append([code(b),num(rad,3),code(arid) if direct else r'\textemdash',orig,eout,oout])
longtable('rq_s1.tex','RQ-S1：固定 radius 下的方向敏感性对照。' if LANG=='zh' else 'RQ-S1: чувствительность к направлению при фиксированном radius.','tab:appB-rq-s1','L{20mm}L{22mm}L{25mm}L{55mm}L{55mm}L{55mm}',[t['benchmark'],t['radius'],t['anchor'],t['orig'],t['e1'],t['ones']],rows,fontsize='6.7pt',leading='7.9pt',tabcolsep='1.8pt')

# RQ-S2 9 cells
s2=[r for r in S if r['research_question_id']=='RQ-S2']
g=defaultdict(dict)
for r in s2:g[r['comparison_anchor']][r['initial_matrix_id']]=r
rows=[]
for anchor,d in sorted(g.items()):
    ar=OD[anchor]; k2=next((v for k,v in d.items() if k.endswith('K1E2')),None); k4=next((v for k,v in d.items() if k.endswith('K1E4')),None)
    rows.append([code(anchor),code(ar['benchmark_instance_id']),code(ar['start_point_id']),code(ar['terminal_status']),code(k2['terminal_status']),code(k4['terminal_status'])])
longtable('rq_s2.tex','RQ-S2：identity H0 与两档 anisotropic SPD H0 的 terminal-status 对照。' if LANG=='zh' else 'RQ-S2: сопоставление terminal status для identity H0 и двух anisotropic SPD H0.','tab:appB-rq-s2','L{20mm}L{45mm}L{45mm}L{43mm}L{43mm}L{43mm}',[t['anchor'],t['benchmark'],t['x0'],t['identity'],t['k1e2'],t['k1e4']],rows,fontsize='6.6pt',leading='7.8pt',tabcolsep='1.8pt')

# RQ-S3
s3=[r for r in S if r['research_question_id']=='RQ-S3']
rows=[[code(r['supp_run_id']),code(r['benchmark_id']),intval(r['dimension']),condition_label(r['condition_number']),code(r['terminal_status']),intval(r['gradient_evaluations']),num(r['wall_elapsed_seconds'],4),num(r['process_peak_rss_mb'],4)] for r in s3]
longtable('rq_s3.tex','RQ-S3：n=100/200 scale supplement。' if LANG=='zh' else 'RQ-S3: дополнение по масштабу n=100/200.','tab:appB-rq-s3','L{22mm}L{24mm}r L{30mm}L{60mm}r L{30mm}L{32mm}',[t['run'],t['benchmark'],t['n'],t['kappa'],t['status'],t['ng'],t['time'],t['rss']],rows,fontsize='7.0pt',leading='8.2pt')

# RQ-S4 combined 8 points
points=[]
for rid,k in [('S5R-0019',1e2),('S5R-0021',1e6),('S5R-0023',1e2),('S5R-0025',1e6)]:
    r=OD[rid]; points.append((int(r['dimension']),k,rid,r['terminal_status'],r['gradient_evaluations'],r['final_gradient_norm']))
for r in S:
    if r['research_question_id']=='RQ-S4': points.append((int(r['dimension']),float(r['condition_number']),r['supp_run_id'],r['terminal_status'],r['gradient_evaluations'],r['final_gradient_norm']))
points.sort(key=lambda x:(x[0],x[1]))
rows=[[str(n),condition_label(k),code(rid),code(st),intval(ng),num(gn)] for n,k,rid,st,ng,gn in points]
longtable('rq_s4.tex','RQ-S4：B-02 conditioning sequence。' if LANG=='zh' else 'RQ-S4: последовательность обусловленности для B-02.','tab:appB-rq-s4','r L{33mm}L{28mm}L{65mm}r L{42mm}',[t['n'],t['kappa'],t['run'],t['status'],t['ng'],t['grad']],rows,fontsize='7.2pt',leading='8.5pt')

# RQ-S5 required contrast summary
rows=[]
vals=[('START',5,3,12),('H0',6,3,12),('LINE_SEARCH',2,1,12)]
for fac,sc,succ,total in vals: rows.append([code(fac),f'{sc}/{total}',f'{succ}/{total}',str(total)])
longtable('rq_s5.tex','RQ-S5：36 个 controlled contrasts 的 targeted interaction summary。' if LANG=='zh' else 'RQ-S5: targeted interaction summary для 36 контролируемых сравнений.','tab:appB-rq-s5','L{62mm}L{50mm}L{50mm}r',[t['factor'],t['statuschanged'],t['successchanged'],t['total']],rows,fontsize='8.0pt',leading='9.4pt')

# RQ-S6 6 paired rows
s6=[r for r in S if r['research_question_id']=='RQ-S6']
rows=[]
for r in s6:
    ar=OD[r['comparison_anchor']]
    rows.append([code(r['benchmark_id']),code(r['weight_id']),code(ar['terminal_status']),code(r['terminal_status']),intval(ar['gradient_evaluations']),intval(r['gradient_evaluations']),num(ar['secant_residual']),num(r['secant_residual'])])
longtable('rq_s6.tex','RQ-S6：weight × line-search paired comparison。' if LANG=='zh' else 'RQ-S6: парное сравнение weight × line-search.','tab:appB-rq-s6','L{20mm}L{28mm}L{43mm}L{43mm}r r L{36mm}L{36mm}',[t['benchmark'],t['weight'],t['from'],t['to'],t['gfrom'],t['gto'],t['secfrom'],t['secto']],rows,fontsize='6.7pt',leading='7.9pt',tabcolsep='1.8pt')

# F4 direct strong-vs-wolfe from bridge
bycell=defaultdict(dict)
for r in F4: bycell[r['comparison_cell_id']][r['line_search_mode']]=r
rows=[]
for cell,d in sorted(bycell.items()):
    if 'WOLFE' in d and 'STRONG_WOLFE' in d:
        w=d['WOLFE']; sw=d['STRONG_WOLFE']
        rows.append([code(w['benchmark_instance_id']),code(w['start_point_id']),code(sw['terminal_status']),boolmark(sw['success_flag']),code(w['terminal_status']),boolmark(w['success_flag'])])
longtable('f4_bridge.tex',r'F4 bridge：STRONG\_WOLFE 与 WOLFE 的六个 representative cells；new scientific runs = 0。' if LANG=='zh' else r'F4 bridge: STRONG\_WOLFE и WOLFE для шести representative cells; new scientific runs = 0.','tab:appB-f4-bridge','L{50mm}L{55mm}L{43mm}L{15mm}L{43mm}L{15mm}',[t['benchmark'],t['x0'],r'STRONG\_WOLFE',t['success'],'WOLFE',t['success']],rows,fontsize='6.7pt',leading='7.9pt',tabcolsep='1.8pt')

# terminal distributions
for name,rowsrc,idfield,label,cap in [
 ('original_status_distribution.tex',O,'planned_run_id','tab:appB-original-status-dist','原 246 个科学运行的 terminal distribution。' if LANG=='zh' else 'Распределение terminal status для 246 исходных научных запусков.'),
 ('supp_status_distribution.tex',S,'supp_run_id','tab:appB-supp-status-dist','105 个补充运行的 terminal distribution。' if LANG=='zh' else 'Распределение terminal status для 105 дополнительных запусков.')]:
    c=Counter(r['terminal_status'] for r in rowsrc)
    order=['SUCCESS_GRADIENT_NORM','SUCCESS_FUNCTION_CHANGE','DENOMINATOR_TOO_SMALL','NOT_POSITIVE_DEFINITE','NONPOSITIVE_CURVATURE','MAX_ITERATIONS','SYMMETRY_LOSS','LINE_SEARCH_TRIAL_LIMIT_REACHED','NON_DESCENT_DIRECTION']
    rows=[[code(st),str(c[st])] for st in order if c.get(st)]
    longtable(name,cap,label,'L{95mm}r',[t['status'],t['count']],rows,fontsize='8.0pt',leading='9.4pt')

print(f'generated {len(list(OUT.glob("*.tex")))} files in {OUT}')


# Additional complete run-level scalar configuration/result fields.
# Vector-valued final_x and raw histories intentionally remain in electronic data.
rows=[]
for r in O:
    rows.append([code(r['planned_run_id']),intval(r['execution_order_index']),code(r['experiment_id']),code(r['research_question_ids']),intval(r['repetition_id'])])
longtable('original_246_config_c.tex','原 246 个 scientific runs：顺序、Experiment ID、RQ 与 repetition。' if LANG=='zh' else 'Исходные 246 scientific runs: порядок, Experiment ID, RQ и repetition.','tab:appB-original-246-config-c','L{20mm}L{20mm}L{90mm}L{75mm}L{25mm}',[t['run'],t['order'],t['expid'],t['rqids'],t['rep']],rows,fontsize='6.8pt',leading='8.0pt',tabcolsep='1.8pt')
rows=[]
for r in O:
    rows.append([code(r['planned_run_id']),code(r['tolerance_profile_id']),code(r['budget_profile_id'])])
longtable('original_246_config_d.tex','原 246 个 scientific runs：逐运行 tolerance / budget profile。' if LANG=='zh' else 'Исходные 246 scientific runs: профили tolerance / budget для каждого запуска.','tab:appB-original-246-config-d','L{20mm}L{100mm}L{100mm}',[t['run'],t['tol'],t['budget']],rows,fontsize='7.0pt',leading='8.2pt',tabcolsep='1.9pt')
rows=[]
for r in O:
    rows.append([code(r['planned_run_id']),code(r['termination_class']),intval(r['accepted_steps']),intval(r['hessian_evaluations']),num(r['wall_elapsed_seconds'],4),num(r['process_peak_rss_mb'],4)])
longtable('original_246_results_b.tex','原 246 个 scientific runs：附加计数、termination class 与环境性能字段。' if LANG=='zh' else 'Исходные 246 scientific runs: дополнительные счётчики, termination class и performance-поля среды.','tab:appB-original-246-results-b','L{20mm}L{65mm}L{30mm}L{30mm}L{40mm}L{40mm}',[t['run'],t['termclass'],t['accepted'],t['nh'],t['time'],t['rss']],rows,fontsize='6.8pt',leading='8.0pt',tabcolsep='1.8pt')
rows=[]
for r in O:
    rows.append([code(r['planned_run_id']),num(r['terminal_curvature']),num(r['terminal_secant_residual']),num(r['terminal_symmetry_error_after']),num(r['terminal_min_eigenvalue_after'])])
longtable('original_246_diagnostics_c.tex','原 246 个 scientific runs：terminal-update diagnostics。' if LANG=='zh' else 'Исходные 246 scientific runs: terminal-update diagnostics.','tab:appB-original-246-diag-c','L{20mm}L{50mm}L{50mm}L{50mm}L{50mm}',[t['run'],t['termcurv'],t['termsec'],t['termsym'],t['termeig']],rows,fontsize='6.8pt',leading='8.0pt',tabcolsep='1.8pt')

rows=[]
for r in S:
    rows.append([code(r['supp_run_id']),intval(r['execution_order']),code(r['classification']),code(r['start_seed'])])
longtable('supp_105_config_e.tex','105 个 supplementary runs：顺序、classification 与 start seed。' if LANG=='zh' else '105 supplementary runs: порядок, classification и start seed.','tab:appB-supp-config-e','L{20mm}L{25mm}L{70mm}L{70mm}',[t['run'],t['order'],t['class'],t['seed']],rows,fontsize='7.1pt',leading='8.3pt',tabcolsep='1.9pt')
rows=[]
for r in S:
    rows.append([code(r['supp_run_id']),code(r['termination_class']),intval(r['accepted_steps']),intval(r['hessian_evaluations']),num(r['final_step_norm'])])
longtable('supp_105_results_b.tex','105 个 supplementary runs：termination class、accepted steps、Nh 与最终步长。' if LANG=='zh' else '105 supplementary runs: termination class, accepted steps, Nh и итоговый шаг.','tab:appB-supp-results-b','L{20mm}L{75mm}L{32mm}L{30mm}L{55mm}',[t['run'],t['termclass'],t['accepted'],t['nh'],t['stepnorm']],rows,fontsize='7.0pt',leading='8.2pt',tabcolsep='1.8pt')
rows=[]
for r in S:
    rows.append([code(r['supp_run_id']),intval(r['last_valid_iteration']),code(r['terminal_row_status']),num(r['terminal_curvature']),num(r['terminal_secant_residual'])])
longtable('supp_105_diagnostics_c.tex','105 个 supplementary runs：terminal-row 与 curvature/secant diagnostics。' if LANG=='zh' else '105 supplementary runs: terminal-row и curvature/secant diagnostics.','tab:appB-supp-diag-c','L{20mm}L{28mm}L{72mm}L{50mm}L{50mm}',[t['run'],t['last'],t['termrow'],t['termcurv'],t['termsec']],rows,fontsize='6.8pt',leading='8.0pt',tabcolsep='1.8pt')
rows=[]
for r in S:
    rows.append([code(r['supp_run_id']),num(r['terminal_symmetry_error_after']),num(r['terminal_min_eigenvalue_after'])])
longtable('supp_105_diagnostics_d.tex','105 个 supplementary runs：terminal-update symmetry / eigenvalue diagnostics。' if LANG=='zh' else '105 supplementary runs: terminal-update symmetry / eigenvalue diagnostics.','tab:appB-supp-diag-d','L{20mm}L{100mm}L{100mm}',[t['run'],t['termsym'],t['termeig']],rows,fontsize='7.0pt',leading='8.2pt',tabcolsep='1.9pt')
