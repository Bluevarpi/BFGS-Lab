# Appendix B data field dictionary

This directory contains analysis exports used to build Appendix B tables without reopening solver raw files.

## Files

- `original_246_reference_summary.csv`: frozen original-run reference metrics from the reference baseline.
- `supplementary_105_master.csv`: one row per supplementary run, including frozen configuration identity, terminal result, work counters, final-state diagnostics, wall time, and process peak RSS.
- `supplementary_family_summary.csv`: family-level counts and descriptive medians.
- `supplementary_failure_analysis.csv`: all scientific non-success outcomes; these are valid scientific results, not driver failures.
- `supplementary_rq_findings.csv`: compact RQ-S1--RQ-S6 interpretation table.
- `f4_strong_wolfe_analysis_bridge.csv`: zero-new-run bridge combining original F4 rows with the six already-existing original STRONG_WOLFE anchors.

## Key configuration fields

- `supp_run_id`: supplementary identity `SUPP-R0001`--`SUPP-R0105`.
- `supp_family`, `research_question_id`, `classification`: design grouping.
- `benchmark_id`, `benchmark_instance_id`, `dimension`, `condition_number`: problem definition.
- `start_point_id`, `start_direction_id`, `start_radius`, `start_seed`: initial-point definition.
- `initial_matrix_id`, `initial_matrix_condition_number`: initial inverse-Hessian definition.
- `update_implementation_id`, `weight_id`, `step_line_search_id`: algorithm/update/globalization profiles.
- `tolerance_profile_id`, `budget_profile_id`: frozen stopping and budget profiles.

## Key result fields

- `terminal_status`, `success_flag`, `termination_class`: terminal scientific outcome. Non-success does not mean execution failure.
- `iterations`, `accepted_steps`: iteration/state counters.
- `function_evaluations`, `gradient_evaluations`, `hessian_evaluations`, `line_search_trials`: work counters.
- `final_f`, `final_gradient_norm`, `final_x`, `final_step_norm`: final committed-state values.
- `secant_residual`, `symmetry_error`, `minimum_eigenvalue`: final structural diagnostics.
- `known_x_error`, `known_f_error`: errors against the registered known target where available.
- `last_valid_iteration`, `terminal_*`: diagnostics around the last valid/terminal update.
- `wall_elapsed_seconds`, `process_peak_rss_mb`: current-environment performance measurements only; do not compare strictly with historical-machine timing.

## F4 bridge fields

- `source=ORIGINAL_F4` denotes original F4 rows.
- `source=ORIGINAL_STRONG_WOLFE_ANCHOR` denotes the already-existing original strong-Wolfe comparison run.
- `new_scientific_run=0` for every bridge row.
