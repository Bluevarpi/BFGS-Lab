No external logo, seal, or image asset is required by the document. The title page is typeset entirely in LaTeX/TikZ.
