# Structured excerpt from src/s6_bfgs/updates.py.
def compact_candidate(H, z, y, delta):
    rho = 1.0 / delta
    I = np.eye(H.shape[0], dtype=np.float64)
    return ((I - rho * np.outer(z, y)) @ H
            @ (I - rho * np.outer(y, z))
            + rho * np.outer(z, z))


def expanded_candidate(H, z, y, delta):
    r = z - H @ y
    return (H
            + (np.outer(r, z) + np.outer(z, r)) / delta
            - float(y @ r) * np.outer(z, z) / (delta * delta))


def weighted_candidate(H, z, y, delta, a, b):
    r = z - H @ y
    return (H
            + a * (np.outer(r, z) + np.outer(z, r)) / delta
            - b * float(y @ r) * np.outer(z, z) / (delta * delta))

# update_inverse_hessian applies the registered denominator guard first,
# then finite/symmetry/positive-definite checks to the candidate matrix.
