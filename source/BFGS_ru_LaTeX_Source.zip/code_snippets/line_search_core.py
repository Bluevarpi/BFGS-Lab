# Structured excerpt from src/s6_bfgs/line_search.py.
if mode == "ARMIJO":
    alpha = float(config["alpha0"])
    while alpha >= float(config["alpha_min"]):
        candidate = evaluate(alpha, False)
        if candidate.record.armijo_satisfied:
            return accept(candidate)
        alpha *= float(config["beta"])
    return _result(Status.LINE_SEARCH_FAILED, trials)

if mode not in {"WOLFE", "STRONG_WOLFE"}:
    return _result(Status.LINE_SEARCH_FAILED, trials)

c2 = float(config["c2"])
def condition(candidate):
    if mode == "WOLFE":
        return bool(candidate.record.armijo_satisfied
                    and candidate.record.curvature_satisfied)
    return bool(candidate.record.armijo_satisfied
                and candidate.record.strong_curvature_satisfied)
