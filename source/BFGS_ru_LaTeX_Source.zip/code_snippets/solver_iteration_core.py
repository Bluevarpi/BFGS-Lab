# Structured excerpt from src/s6_bfgs/solver.py.
# Validation, budgets, cache and record serialization are omitted here only.
tracker.advance(InternalState.COMPUTING_DIRECTION)
p = -(committed.H @ committed.g)

tracker.advance(InternalState.SEARCHING_STEP)
ls = line_search(
    run_id=rid, iteration=committed.iteration,
    evaluator=evaluator, budget=budget,
    x=committed.x, f=committed.f, g=committed.g,
    p=p, config=config.line_search, cancel=cancel,
)

x_new, f_new, g_new = ls.x_new.copy(), float(ls.f_new), ls.g_new.copy()
z = x_new - committed.x
y = g_new - committed.g
update = update_inverse_hessian(
    committed.H, z, y, config.update,
    str(config.solver["update-mode"]),
)
H_new = update.H_new

before = matrix_diagnostics(committed.H)
after = matrix_diagnostics(H_new)
tracker.advance(InternalState.COMMITTING_STATE)
committed = CommittedState(
    committed.iteration + 1, x_new, f_new, g_new, H_new.copy()
)
tracker.advance(InternalState.CHECKING_STOP)
if float(np.linalg.norm(g_new)) <= grad_tol:
    return _terminal(result, Status.SUCCESS_GRADIENT_NORM, final=committed)
