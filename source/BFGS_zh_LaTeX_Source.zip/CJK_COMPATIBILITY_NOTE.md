# 中文字体配置

本版本使用 CTeX 自带的 `fontset=fandol` 处理中文，西文和俄文仍使用 CMU Serif.

- 编译器：LuaLaTeX
- 中文正文：Fandol Song
- 中文无衬线字体：Fandol Hei
- 不在源码 ZIP 中附带任何字体文件
- 不依赖 `Noto Serif CJK SC`、`Noto Sans CJK SC` 等外部字体名称

该配置适用于带有完整 CTeX/Fandol 组件的 TeX Live 环境，可避免在线编译平台因缺少 Noto CJK 字体而停止编译.
